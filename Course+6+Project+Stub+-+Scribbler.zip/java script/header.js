
//signin modal
var signinmodal = document.getElementById('modelSignIn');

// opens the modal of Sign In
var signinbtn = document.getElementById("sign-in-btn");

// Get the <span> element that closes the modal
var signinspan = document.getElementsByClassName("close")[0];

// When we click the buttons it opens the modal
signinbtn.onclick = function() {
  signinmodal.style.display = "block";
}

// when any click it close the model
signinspan.onclick = function() {
  signinmodal.style.display = "none";
}

SignUp.onclick = function() {
  signupmodal.style.display = "block";
  signinmodal.style.display = "none";
}
// When we clicks anywhere outside of the modal, close it
window.addEventListener('click' , function(event) {
  if (event.target == signinmodal) {
    signinmodal.style.display = "none";
  }
});

// for signup modal
var signupmodal = document.getElementById('modelSignUp');

// opens the modal
var signupbtn = document.getElementById("sign-up-btn");

// closes the modal
var signupspan = document.getElementsByClassName("close")[1];

// When we clicks the button, open the modal 
signupbtn.onclick = function() {
  signupmodal.style.display = "block";
}

// clicking span will close the modal
signupspan.onclick = function() {
  signupmodal.style.display = "none";
}

// When we clicks anywhere outside of the modal, close it
window.addEventListener('click' , function(event) {
  if (event.target == signupmodal) {
    signupmodal.style.display = "none";
  }
});
